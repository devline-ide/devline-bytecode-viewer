# @devline/ui-web

Private shared Vue UI for DevLine IDE and future generated web applications.
No project, filesystem, JPHP or desktop-host dependencies.

```ts
import { createApp } from 'vue'
import { installUI } from '@devline/ui-web'
import '@devline/ui-web/style.css'

const app = createApp(App)
installUI(app, { locale: applicationLocale })
app.mount('#app')
```

Import controls explicitly. Complex controls delegate keyboard/overlay behavior to
PrimeVue 4.5.5 in unstyled mode. One `UIToastHost` belongs in the application shell;
`useUIToast()` is called during component setup. Styling uses the shared semantic
variables in `src/styles/_colors.scss`. Load application theme overrides after the
kit stylesheet. No control relies on IDE state or bridge transport.

Desktop density is defined in `src/styles/_density.scss`: 13px UI text, 12px
secondary text, 32px fields, 30px buttons, 16px icons and 7px control corners.
Settings layouts share the same parameters (230px sidebar, 780px content and
50px rows). Override these semantic CSS variables after the kit stylesheet if
an application needs a different density; do not use zoom or scaling transforms.
The compact spacing scale is 4/6/8/12/16/20/24/32px. Light uses white surfaces,
dark uses neutral charcoal, and standard retains the DevLine emerald palette.

The bundled themes are `standard` (default), `dark` and `light`. Set `data-theme="light"` on
the document root for the latter. `UIThemePreference` includes `system`; the host
resolves the media query and owns persistence. Custom themes override the same
semantic parameters, without rewriting component CSS or replacing controls.

## Value contracts

| Component | Model / action |
| --- | --- |
| UIInput | string |
| UISelect | string / number / null |
| UIMultiSelect | array of strings / numbers |
| UICheckbox | boolean |
| UIDatePicker | YYYY-MM-DD / null (local calendar, not UTC timestamp) |
| UIColorPicker | #RRGGBB string, native platform picker |
| UIButton | click event without native event payload |
| UIContextMenu | select event with item ID string |

Select options are `{ label, value, disabled? }`. Single-select never shows
checkboxes; only multiselect uses them. Date bounds use the same ISO calendar
format. Supply a visible label linked with `inputId`/`id` for native inputs.
For `UISelect` use a visible label ID through `ariaLabelledby`, or `ariaLabel`.
Use `aria-label` for icon-only native controls. Forward `aria-describedby` for help or validation text.
Every screen owns its model and validation; wrappers own only transient UI state.
`UIInput` keeps a string model even for `type="number"`; parse numeric values at
the application boundary. Checkbox, date and color input types use their dedicated controls.

`UIInfoTip` uses styled `v-tippy` with keyboard, focus and touch activation.
For an existing element, import `vUITooltip` as `vTooltip` and use `v-tooltip`
with `theme: 'devline'`, `allowHTML: false` and `trigger: 'mouseenter focus'`.
Focus outlines default to off. A host can enable them by setting
`data-focus-outlines="on"` on the document root; keyboard behavior and selection
backgrounds remain available in either mode. The IDE persists this choice in
Appearance settings, while other applications own their own preferences.
Localization is supplied by the application through PrimeVue locale configuration
and explicit control labels, not baked into application-specific screens here.
Call `setUILocale(app, locale)` after changing the host's active language. It merges
the supplied control translations with installed defaults, including ARIA labels.

There is no JPHP reactive binding implementation yet. The serializable model
contracts are ready for a separate renderer/adapter, not proof that this adapter
already exists. Exported UI components are normal Vue components, usable without
the IDE.

## Variable-size virtual lists

`UIVirtualList` uses [TanStack Vue Virtual](https://tanstack.com/virtual/latest/docs/framework/vue/vue-virtual)
3.13.39. Vertical mode measures changing item heights, horizontal mode measures
changing widths with ResizeObserver. The consumer gives the viewport a bounded
height/width; `crossAxis="natural"` keeps content's natural cross-axis size rather
than stretching it. This is a one-axis list, not a two-dimensional grid.

```vue
<UIVirtualList ref="list" :items="rows" item-key="id" :height="400"
  :estimate-size="64" :overscan-before="3" :overscan-after="8" :gap="8">
  <template #default="{ item, index }">
    <article>{{ index + 1 }}. {{ item.title }}</article>
  </template>
  <template #empty>No items</template>
</UIVirtualList>
```

Props: `axis` (vertical/horizontal), `estimateSize` (positive pixel size or
Vue-local item/index callback), independent `overscanBefore`/`overscanAfter`
(item counts), `gap`, `paddingStart`, `paddingEnd`, `width`, `height`, `crossAxis`,
`enabled`, `ariaLabel`, `motion` (none/fade) and `motionDuration` (milliseconds).
`:enabled="false"` suspends observers and row rendering for an inactive panel;
it does not render the entire unvirtualized dataset. Bind it as a boolean prop.
`itemKey` is a unique string/safe-integer property or Vue-local accessor; use
persistent IDs rather than array indices when inserting/reordering data. The
future JPHP adapter supplies registered field accessors, not serialized functions.

The slot receives `item`, `index`, `itemKey`, and current `measuredSize`.
`rangeChange` emits visible/rendered start/end indices (`-1` when empty), total
count and axis. `scroll` emits offset, viewport/total size, direction, scrolling
state and axis, never native events. Exposed methods are `scrollToIndex`,
`scrollToOffset` (optional align/behavior), and `measure`. DOM observers are
disposed with the component by the maintained virtualizer adapter. Slot state
that must survive virtualization belongs in the parent's item model.

Optional fade affects opacity only. Rows leave the DOM immediately to avoid
phantom height/width; placement and measurement are never animated. Reduced
motion disables fades and forces instant programmatic scrolling.

Focused range/key checks: from the repository root, run
`node --experimental-strip-types --test devline-ui-web/tests/virtual-list.test.mjs`.
The browser fixture in `tests/browser/index.html` exercises variable heights,
widths, content growth, viewport resize and scrolling to the end.
## Modal stack

Wrap the application's content once in `UIModalProvider`. Register dialogs under
it with a unique, immutable `id`, `title` and `v-model:open`. `UIModal` accepts
`size="sm|md|lg"`, `body-scroll`, `close-on-escape`, `close-on-backdrop`,
`show-close` and optional localized `close-label`. The default close label follows
the shared locale. Content uses the default slot, actions use `#footer`.

Backdrop dismissal is disabled by default. Opt in with `:close-on-backdrop="true"`; only a gesture starting and ending on the backdrop dismisses the dialog.

`useUIModalStack()` exposes `open(id, payload?)`, top-only `close(id?)`, `back()`,
`closeAll()`, `payloadFor(id)` and readonly `activeId`, `stackIds`, `depth`.
Payloads are detached JSON values; close events are `{ id, reason }`, never DOM
events. Unknown IDs return `false`. Remount using `:key` to change dialog identity.

Opening another dialog parks the previous layer: it stays mounted and retains
form state, but becomes hidden and inert. Back restores its previous focus.
Closing retains the top layer and scroll lock through the exit transition;
reopening cancels that transition. Provider teardown removes keyboard listeners
and restores body styles. Shared select/calendar popups remain above their owner
and Escape dismisses the popup before the dialog. No drag manager or parking shelf
is invented: parking follows the actual nested-modal source behavior.
