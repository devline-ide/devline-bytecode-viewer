# DevLine extension web devkit

This package owns the shared TypeScript configuration and type-only contracts
for extension webviews. It contains no IDE shell imports, UI implementation or
runtime bridge. The runtime remains the host-injected `window.devline` object
implemented in `src/main/resources/devline/extensions/webview-sdk.js`.

The initial compiler options are preserved from the IDE shell's `tsconfig.json`.
Consumers own their `include`, `exclude`, output paths and extension-specific RPC
types. Use `extends: "@devline/extension-devkit/tsconfig.json"` and import
`DevLineWebviewContext` / `DevLineWebviewSdk` as types.

The first distribution uses a versioned `npm pack --ignore-scripts` tarball in
each extension's `vendor/` directory, installed by `npm ci`. Its lockfile records
the npm integrity; `vendor/extension-devkit.json` records SHA-256 and the owning
SDK source commit. This is a frozen package dependency, not a maintained source
copy. No private npm registry credential or sibling shell directory is needed.

Create distributions with `tools/extensions/package_web_devkit.py` from the IDE
repository. Change the package version before distributing different package
bytes. Do not rewrite published package archives in place.
