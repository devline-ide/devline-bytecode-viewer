/** Context sent to an extension webview by the IDE host. */
export interface DevLineWebviewContext {
  locale: string
  theme: string
  visible: boolean
  colors?: Record<string, string>
  effects?: Record<string, string>
  projectFile?: string
  selectedPath?: string
  selectionRevision?: number
  view?: {
    id: string
    location: 'dock' | 'sidebar' | 'settings'
    settingsScope?: 'user' | 'workspace'
    readOnly?: boolean
  }
  document?: { path: string }
}

/** Type-only contract for the host-injected window.devline object.
 * Await ready before accessing the initial context. Runtime implementation is
 * owned by webview-sdk.js; this package does not bundle or replace that bridge.
 */
export interface DevLineWebviewSdk<Context extends DevLineWebviewContext = DevLineWebviewContext> {
  ready: Promise<Context>
  log(level: 'debug' | 'info' | 'warn' | 'error', message: string): void
  getContext(): Context
  getState(): unknown
  setState(value: unknown): void
  onContextChanged(listener: (context: Context) => void): () => void
  onBeforeDocumentSave(listener: () => void | Promise<void>): () => void
  call<Result = unknown>(method: string, arguments_?: Record<string, unknown>): Promise<Result>
}
