# DevLine Web game renderer

An ordered WebGL 2 sprite/quad batcher, independent of PHP, Vue and IDE services.
The renderer consumes positions, UV regions, premultiplied texture samples, colors
and particle coverage. It batches adjacent primitives using the same texture and
never reorders translucent sprites or 2.5D faces.

`devline-ui-web/src/runtime/level-webgl.ts` adapts the existing level projection.
`UIFormLevelFragment` owns contexts, renderer selection, Canvas fallback, context
loss/restoration, capture and disposal. Translucent backgrounds retain their
existing Canvas trail semantics by falling back to Canvas. GPU texture storage
has a 128 MiB LRU budget per fragment; textures and geometry buffers are released
on unmount or renderer changes.

Project Settings > Run selects Automatic, WebGL 2 or Canvas 2D for Web/Desktop Web.
The native application continues using the Kotlin/JavaFX renderer, with automatic
platform graphics selection or an explicit software pipeline. Game code and assets
are unchanged. No WebGL support or physical GPU performance is inferred from the
presence of a JVM or a browser.

Build: `npm run build --workspace @devline/game-render-web`. It is also a dependency
of the Gradle `uiBuild` task. Replays and browser acceptance live in
`tests/game-render-benchmark.mjs`; real PHP games are checked separately by
`tests/game-render-runtime.mjs`. See the performance audit for measured scope.

API reference: https://registry.khronos.org/webgl/specs/2.0.0/
